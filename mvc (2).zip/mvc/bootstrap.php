<?php
require __DIR__ .'/vendor/autoload.php';
require __DIR__ .'/router.php';

//$controller = new Src\Controller;
//$controller = new App\controllers\UsersController;
//echo $controller->handler();
$object = $router->handler();

//$controller = new $object['class'](new App\Models\User);
//$action = $object['action'];
//echo $controller->$action();
(new Src\Resolver)->handler($object['class'], $object['action']);