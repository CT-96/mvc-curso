<?php

namespace Src;

class Model
{
    public function get()
    {
        return [
            'name'=>'carlos'
        ];
    }
}