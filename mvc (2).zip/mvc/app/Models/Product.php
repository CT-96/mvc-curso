<?php

namespace App\Models;

use Src\Model;

class Product extends model
{
    
}