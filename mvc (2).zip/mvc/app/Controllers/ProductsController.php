<?php

namespace App\Controllers;
use Src\Controller;
use App\Models\Pruduct;

class ProductsController extends Controller
{ 
  public function __construct(Product $model)
    {
      $this->model = $model;
    }

   public function index()
   {
      $this->render();
   } 
   
}