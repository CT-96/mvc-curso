<?php

namespace app\Controllers;

class UsersControllers
{
    public function handler()
    {
        return self::class;
    }  
  }