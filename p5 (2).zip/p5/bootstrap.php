<?php
require __DIR__ .'/vendor/autoload.php';

$controller = new SON\Controller;
echo $controller->handler();