<?php
namespace SON;
class Controller
{
  public function handler()
  {
      return self::class;
  }  
}
