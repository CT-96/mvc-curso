<?php

$router = new Src\Router;
$router['/'] = [
    'class' => 'App\controllers\UsersController',
    //'controller' => App\controllers\UsersControlle::class,
    'action' => 'index'
];
$router['/registro'] = [
    'class' => 'App\controllers\UsersController',
    //'controller' => App\controllers\UsersControlle::class,
    'action' => 'create'
];
return $router;

