<?php

namespace App\Controllers;
use Src\Controller;

class UsersController extends Controller
{
   public function index()
   {
      $this->render(['name' => 'virginia', 'users/index']);
   } 
   public function create()
   {
      return 'cadastro de usuarios';
   } 
   
}