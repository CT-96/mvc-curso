<?php

namespace Src;

class Controller
{
    public function render(array $data = [], string $view = null)
    {
      extract($data);
      require __DIR__ . '/../template/'.$view.'.tpl.php';


    }
}